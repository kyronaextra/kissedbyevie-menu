/* Evie Admin Docker Control — uses EXISTING Supabase admin request function.
 * No extra browser token, no direct PC network calls, no raw Docker commands.
 */
(function(){
  'use strict';
  const state={request:null,timer:null,started:false,inflight:false};
  let root=null;
  const node=(tag,cls,text)=>{const v=document.createElement(tag);if(cls)v.className=cls;
    if(text!==undefined)v.textContent=String(text);return v;};
  function status(s){if(root)root.querySelector('[data-role="status"]').textContent=s;}
  function init(){
    if(root)return;
    const panel=document.getElementById('panel-docker');if(!panel)return;
    root=node('section','surface evie-control');root.id='evieLiveDockerControl';
    root.append(node('h2','','Live Docker control'),node('p','hint',
      'Commands are authenticated, audited and forwarded to your local outbound-only worker. They never go directly from the browser to Docker.'));
    root.append(node('p','hint','Connecting to the worker…'));
    root.lastChild.dataset.role='status';
    const actions=node('div','evie-control-actions');
    for(const verb of ['start','stop','restart','logs']){
      const label=node('label','',''+verb.toUpperCase()+'  ');
      const sel=node('select');sel.dataset.verb=verb;
      for(const service of ['api','listener']){const op=node('option','',service);op.value=service;sel.append(op)}
      const button=node('button','secondary small',verb.toUpperCase());button.type='button';
      button.addEventListener('click',()=>command(sel.value,verb));label.append(sel,button);actions.append(label);
    }
    for(const verb of ['pause','resume']){
      const button=node('button','secondary small',verb==='pause'?'Pause profiler':'Resume profiler');
      button.type='button';button.addEventListener('click',()=>command('api',verb));actions.append(button);
    }
    const refresh=node('button','secondary small','Refresh status');refresh.type='button';
    refresh.addEventListener('click',()=>update());actions.append(refresh);root.append(actions);
    const out=node('pre','evie-control-output','No commands submitted.');out.dataset.role='output';root.append(out);
    panel.append(root);
  }
  async function command(service,verb){
    if(state.inflight||!state.request)return;
    if(['stop','restart','pause'].includes(verb)&&!window.confirm(
      'Send '+verb.toUpperCase()+' to '+service+'? This can interrupt event processing.'))return;
    state.inflight=true;
    root.querySelectorAll('button').forEach(b=>b.disabled=true);
    try{
      const response=await state.request('worker_command',{service,verb});
      status('Queued '+verb+' for '+service+' ('+response.id+'). Results appear below.');
      await update();
    }catch(err){status('Request rejected: '+(err.message||'Unknown error'));}
    finally{state.inflight=false;root.querySelectorAll('button').forEach(b=>b.disabled=false);}
  }
  async function update(){
    if(!state.request||!root)return;
    try{
      const [worker,history]=await Promise.all([
        state.request('worker_state'),state.request('worker_commands'),
      ]);
      const active=(worker.workers||[]).filter(x=>Date.now()-new Date(x.heartbeat_at).getTime()<60000);
      const flags=active.map(w=>w.worker_id+' · '+(w.paused?'INGEST PAUSED':'ingest active')+' · '+
        Object.entries(w.services||{}).map(([k,v])=>k+':'+v.state).join(', '));
      status(active.length?'Worker online: '+flags.join(' | '):'Worker offline / not yet paired. Commands expire after five minutes.');
      const lines=(history.commands||[]).slice(0,12).map(c=>{
        const detail=c.result?.logs||c.result?.message||'';
        return new Date(c.requested_at).toLocaleString()+' '+c.verb+' '+c.service+' → '+c.status+
          (detail?'\n'+String(detail).slice(0,3500):'');
      });
      root.querySelector('[data-role="output"]').textContent=lines.join('\n\n')||'No recent commands.';
    }catch(err){status('Could not retrieve Docker status: '+(err.message||'Unknown error'));}
  }
  function start(config){
    if(state.started)return;
    state.request=config.request;state.started=true;init();update();
    state.timer=setInterval(()=>{if(!document.hidden)update();},12000);
  }
  function stop(){clearInterval(state.timer);state.timer=null;state.started=false;
    state.request=null;if(root){root.remove();root=null;}}
  window.EvieControlBridge={start,stop,refresh:update};
})();
