import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import {createClient} from "npm:@supabase/supabase-js@2.58.0";

// IMPORTANT: deploy with verify_jwt=false. Authentication here is the separate
// long random bearer token set ONLY in Edge secrets and the local Docker worker.
const url=Deno.env.get('SUPABASE_URL')||'';
const key=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')||'';
const workerToken=Deno.env.get('EVIE_CONTROL_WORKER_TOKEN')||'';
const db=createClient(url,key,{auth:{persistSession:false,autoRefreshToken:false}});
const encoder=new TextEncoder();
const uuid=/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
function json(status:number, payload:Record<string,unknown>) {
  return new Response(JSON.stringify(payload),{status,headers:{'Content-Type':'application/json; charset=utf-8',
    'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
}
async function equal(a:string,b:string){
  const ah=new Uint8Array(await crypto.subtle.digest('SHA-256',encoder.encode(a)));
  const bh=new Uint8Array(await crypto.subtle.digest('SHA-256',encoder.encode(b)));
  let diff=0;for(let i=0;i<ah.length;i++)diff|=ah[i]^bh[i];
  return diff===0;
}
Deno.serve(async req=>{
  if(req.method!=='POST')return json(405,{error:'POST required'});
  if(req.headers.has('origin'))return json(403,{error:'Browser access not allowed'});
  if(!url||!key||workerToken.length<40)return json(503,{error:'Relay not configured'});
  const auth=req.headers.get('authorization')||'';
  if(!auth.startsWith('Bearer ')||!(await equal(auth.slice(7),workerToken)))return json(401,{error:'Unauthorized'});
  const length=Number(req.headers.get('content-length')||0);
  if(length>10000)return json(413,{error:'Too large'});
  try{
    const raw=await req.text();if(raw.length>10000)return json(413,{error:'Too large'});
    const payload=JSON.parse(raw);
    const worker=String(payload?.worker_id||'');
    if(!/^[a-zA-Z0-9_-]{3,40}$/.test(worker))return json(400,{error:'Invalid worker'});
    if(payload.action==='heartbeat'){
      const submitted=payload.services;
      if(!submitted||typeof submitted!=='object'||Array.isArray(submitted)||
        Object.keys(submitted).some(x=>!['api','listener'].includes(x)))return json(400,{error:'Invalid service state'});
      const services:Record<string,{state:string,status:string}>={};
      for(const k of Object.keys(submitted)){
        const v=submitted[k];
        if(typeof v?.state!=='string'||typeof v?.status!=='string')return json(400,{error:'Invalid state'});
        services[k]={state:v.state.slice(0,24),status:v.status.slice(0,120)};
      }
      const {error}=await db.from('evie_admin_worker_state').upsert({
        worker_id:worker,heartbeat_at:new Date().toISOString(),services,paused:payload.paused===true,
      },{onConflict:'worker_id'});
      return error?json(503,{error:'Unable to record heartbeat'}):json(200,{ok:true});
    }
    if(payload.action==='poll'){
      const {data,error}=await db.rpc('evie_worker_claim_next',{p_worker:worker});
      if(error)return json(503,{error:'Unable to claim command'});
      const c=data?.[0];
      return json(200,{command:c?{id:c.id,service:c.service,verb:c.verb}:null});
    }
    if(payload.action==='complete'){
      const id=String(payload.id||'');
      if(!uuid.test(id)||!['succeeded','failed'].includes(payload.status))return json(400,{error:'Invalid completion'});
      const result=payload.result;
      if(!result||typeof result!=='object'||Array.isArray(result)||JSON.stringify(result).length>8500)
        return json(400,{error:'Invalid result'});
      const {data,error}=await db.from('evie_admin_worker_commands')
        .update({status:payload.status,result,completed_at:new Date().toISOString()})
        .eq('id',id).eq('claimed_by',worker).eq('status','running').select('id').maybeSingle();
      if(error)return json(503,{error:'Unable to record result'});
      return data?json(200,{ok:true}):json(404,{error:'Command not found'});
    }
    return json(404,{error:'Unknown action'});
  }catch{return json(400,{error:'Invalid request'});}
});
