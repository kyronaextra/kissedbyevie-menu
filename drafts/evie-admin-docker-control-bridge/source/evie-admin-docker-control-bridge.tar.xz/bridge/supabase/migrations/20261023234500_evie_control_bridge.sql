-- Control plane; no access to these tables from browser anon/authenticated roles.
-- Existing admin-api Edge Function (service_role) is the ONLY public admin gateway.
create table if not exists public.evie_admin_worker_commands (
  id uuid primary key default gen_random_uuid(),
  service text not null check(service in ('api','listener')),
  verb text not null check(verb in ('start','stop','restart','logs','pause','resume')),
  status text not null default 'queued' check(status in ('queued','running','succeeded','failed','expired')),
  actor uuid not null references auth.users(id),
  requested_at timestamptz not null default now(),
  started_at timestamptz,
  completed_at timestamptz,
  claimed_by text,
  result jsonb not null default '{}'::jsonb
);
create index if not exists evie_admin_worker_commands_recent
  on public.evie_admin_worker_commands(requested_at desc);
create index if not exists evie_admin_worker_commands_pending
  on public.evie_admin_worker_commands(requested_at)
  where status='queued';

create table if not exists public.evie_admin_worker_state (
  worker_id text primary key,
  heartbeat_at timestamptz not null,
  services jsonb not null default '{}'::jsonb,
  paused boolean not null default false
);

alter table public.evie_admin_worker_commands enable row level security;
alter table public.evie_admin_worker_state enable row level security;
revoke all on public.evie_admin_worker_commands from anon, authenticated, public;
revoke all on public.evie_admin_worker_state from anon, authenticated, public;
grant all on public.evie_admin_worker_commands to service_role;
grant all on public.evie_admin_worker_state to service_role;

create or replace function public.evie_worker_claim_next(p_worker text)
returns setof public.evie_admin_worker_commands
language plpgsql security definer set search_path = '' as $$
begin
  if auth.role() is distinct from 'service_role' then
    raise exception 'service role required' using errcode='42501';
  end if;
  update public.evie_admin_worker_commands
     set status='expired', completed_at=now(), result='{"error":"Command expired after 5 minutes"}'::jsonb
   where status='queued' and requested_at < now()-interval '5 minutes';
  return query
  with next as (
    select c.id from public.evie_admin_worker_commands c
     where c.status='queued' and c.requested_at>=now()-interval '5 minutes'
     order by c.requested_at asc for update skip locked limit 1
  )
  update public.evie_admin_worker_commands c
     set status='running', claimed_by=p_worker, started_at=now()
    from next where c.id=next.id
    returning c.*;
end $$;
revoke all on function public.evie_worker_claim_next(text) from public, anon, authenticated;
grant execute on function public.evie_worker_claim_next(text) to service_role;
