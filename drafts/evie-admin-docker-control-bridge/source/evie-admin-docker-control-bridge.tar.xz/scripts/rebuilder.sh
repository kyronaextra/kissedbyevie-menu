#!/bin/sh
set -eu
cd /src
touch /tmp/evie-build-stamp
printf 'Evie dev rebuilder watching app/, web/ and Docker files\n'
while true; do
  changed="$(find app web -type f -newer /tmp/evie-build-stamp -print -quit)"
  if [ -z "$changed" ]; then
    changed="$(find Dockerfile requirements.txt compose.yaml -type f -newer /tmp/evie-build-stamp -print -quit)"
  fi
  if [ -n "$changed" ]; then
    echo "Detected change: $changed"
    if docker compose --profile telegram up -d --build api listener; then
      touch /tmp/evie-build-stamp
      echo 'Rebuilt successfully'
    else
      echo 'Build failed; will retry on next interval' >&2
    fi
  fi
  sleep 5
done
