"""Patch a LOCAL checkout of kyronaextra/kissedbyevie-menu. No network, no deploy.

Usage: python scripts/install_into_evie_repo.py /path/to/kissedbyevie-menu
Idempotent. Verifies all edit anchors before writing any files.
"""
from pathlib import Path
import shutil
import sys

package = Path(__file__).resolve().parent.parent


def replace_once(contents: str, needle: str, replacement: str, label: str) -> str:
    if replacement in contents:
        return contents
    if contents.count(needle) != 1:
        raise RuntimeError(f"{label}: expected exactly one edit anchor: {needle!r}")
    return contents.replace(needle, replacement, 1)


def run(repo: Path):
    repo = repo.resolve()
    html_file = repo / "admin.html"
    js_file = repo / "admin.js"
    edge_file = repo / "supabase/functions/evie-admin-api/index.ts"
    if not all(p.is_file() for p in [html_file, js_file, edge_file]):
        raise RuntimeError("This does not look like a checked-out Kissed by Evie repository")
    html = html_file.read_text()
    js = js_file.read_text()
    edge = edge_file.read_text()
    html = replace_once(html, '<link rel="stylesheet" href="admin.css">',
        '<link rel="stylesheet" href="admin.css">\n  <link rel="stylesheet" href="admin-control.css">', 'admin.html CSS')
    html = replace_once(html, '<script defer src="admin-inbox.js"></script>',
        '<script defer src="admin-inbox.js"></script>\n  <script defer src="admin-control.js"></script>', 'admin.html JS')
    js = replace_once(js, 'window.EvieAdminInbox?.start?.({request,client:sb});',
        'window.EvieAdminInbox?.start?.({request,client:sb});\n  window.EvieControlBridge?.start?.({request});', 'admin.js start')
    js = replace_once(js, 'window.EvieAdminInbox?.stop?.();',
        'window.EvieAdminInbox?.stop?.();\n  window.EvieControlBridge?.stop?.();', 'admin.js stop')
    edge = replace_once(edge, 'if(action==="telegram_workers")return json(origin,200,await listPersonalTelegramWorkers());',
        '''if(action==="telegram_workers")return json(origin,200,await listPersonalTelegramWorkers());
    if(action==="worker_state"){
      const {data,error}=await privileged.from("evie_admin_worker_state")
        .select("worker_id,heartbeat_at,services,paused").order("heartbeat_at",{ascending:false}).limit(5);
      if(error)throw new Error("Worker state unavailable");
      return json(origin,200,{workers:data||[]});
    }
    if(action==="worker_commands"){
      const {data,error}=await privileged.from("evie_admin_worker_commands")
        .select("id,service,verb,status,requested_at,completed_at,result")
        .order("requested_at",{ascending:false}).limit(20);
      if(error)throw new Error("Worker commands unavailable");
      return json(origin,200,{commands:data||[]});
    }''', 'evie-admin-api GET')
    edge = replace_once(edge, 'if(payload?.action==="telegram_worker_issue"){',
        '''if(payload?.action==="worker_command"){
     const service=String(payload.service||"");
     const verb=String(payload.verb||"");
     if(!["api","listener"].includes(service)||
        !["start","stop","restart","logs","pause","resume"].includes(verb))
       return json(origin,400,{error:"Unsupported Docker control operation"});
     const {count,error:pendingError}=await privileged.from("evie_admin_worker_commands")
       .select("id",{count:"exact",head:true}).in("status",["queued","running"]);
     if(pendingError)throw new Error("Worker queue unavailable");
     if((count||0)>=12)return json(origin,429,{error:"Worker queue full"});
     const {data,error}=await privileged.from("evie_admin_worker_commands")
       .insert({service,verb,actor}).select("id").single();
     if(error)throw new Error("Unable to queue Docker command");
     await audit(actor,"docker."+verb,"admin",data.id,"Queued Docker "+verb+" for "+service);
     return json(origin,201,{ok:true,id:data.id});
   }
   if(payload?.action==="telegram_worker_issue"){''', 'evie-admin-api POST')
    output = {
        html_file: html, js_file: js, edge_file: edge,
        repo / 'admin-control.js': (package / 'bridge/site/admin-control.js').read_text(),
        repo / 'admin-control.css': (package / 'bridge/site/admin-control.css').read_text(),
        repo / 'supabase/functions/evie-control-relay/index.ts':
            (package / 'bridge/supabase/functions/evie-control-relay/index.ts').read_text(),
        repo / 'supabase/migrations/20261023234500_evie_control_bridge.sql':
            (package / 'bridge/supabase/migrations/20261023234500_evie_control_bridge.sql').read_text(),
    }
    # Only after all anchors are verified does this write to the user's checkout.
    for path, content in output.items():
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.is_file() and path.read_text() == content:
            continue
        if path.is_file() and path.suffix in ('.js','.ts','.html'):
            shutil.copy2(path, path.with_suffix(path.suffix+'.evie-backup'))
        path.write_text(content)
        print('Updated:',path.relative_to(repo))
    print('Ready to review with: git diff --check && git diff')


if __name__=='__main__':
    if len(sys.argv)!=2:
        raise SystemExit('Usage: python scripts/install_into_evie_repo.py /path/to/kissedbyevie-menu')
    run(Path(sys.argv[1]))
