import importlib
import os
import sys
from pathlib import Path
import pytest
from fastapi.testclient import TestClient



def test_auth_and_events(app):
    assert app.get('/healthz').status_code == 200
    assert app.get('/health').status_code == 401
    assert app.get('/feed').status_code == 401
    assert app.post('/ingest', json={}).status_code == 401
    assert app.post('/login', json={'token':'wrong'}).status_code == 401
    assert app.post('/login', json={'token':'read-'+'Y'*48}).status_code == 200
    assert app.get('/health').status_code == 200
    e={'platform':'telegram','event_id':'tg:2:1','chat_id':'2','sender_id':'2','username':'person',
       'name':'Person','text':'Private message','direction':'inbound'}
    import time
    e['ts'] = time.time()
    headers={'Authorization':'Bearer master-'+'X'*48}
    one=app.post('/ingest',headers=headers,json=e)
    assert one.status_code == 202 and not one.json()['duplicate']
    twice=app.post('/ingest',headers=headers,json=e)
    assert twice.status_code == 202 and twice.json()['duplicate']
    feed=app.get('/feed').json()['items']
    assert len(feed) == 1 and feed[0]['event_id'] == 'tg:2:1'
    e['event_id'] = 'tg:2:2'
    e['ts'] = time.time()
    assert app.post('/ingest',headers=headers,json=e).status_code == 202
    assert app.get('/feed').json()['items'][0]['username'] == 'person'
    assert app.get('/profile/2').status_code == 404
    assert app.post('/profile',headers=headers,json={'sender_id':'2','tier':'HIGH SPENDER','ltv_usd':120}).status_code == 202
    assert app.get('/profile/2').json()['ltv_usd'] == 120.0
    assert app.post('/logout').status_code == 200
    assert app.get('/feed').status_code == 401


def test_cross_origin(app):
    response=app.post('/login',headers={'Origin':'https://attacker.invalid'},json={'token':'read-'+'Y'*48})
    assert response.status_code == 403
