import asyncio
import sys
import pytest


def test_allowlist_and_label_matching():
    from app.control_worker import perform, docker_containers

    class Response:
        status_code=200
        def __init__(self, result): self.result=result
        def json(self): return self.result
        def raise_for_status(self): return None
    class Docker:
        async def get(self, url, params=None):
            assert url == '/containers/json'
            return Response([
                {'Id':'12345678', 'Labels':{
                    'com.docker.compose.project':'evie-admin-profiler',
                    'com.docker.compose.service':'listener'},'State':'running','Status':'Up'},
                {'Id':'attacker-id','Labels':{'com.docker.compose.project':'other',
                    'com.docker.compose.service':'listener'},'State':'running','Status':'Up'},
                {'Id':'other-service','Labels':{'com.docker.compose.project':'evie-admin-profiler',
                    'com.docker.compose.service':'controller'},'State':'running','Status':'Up'},
            ])
    docker=Docker()
    result=asyncio.run(docker_containers(docker))
    assert list(result)==['listener']
    assert result['listener']['id']=='12345678'
    with pytest.raises(ValueError): asyncio.run(perform({'service':'controller','verb':'stop'},docker))
    with pytest.raises(ValueError): asyncio.run(perform({'service':'listener','verb':'exec'},docker))


def test_log_demux():
    from app.control_worker import clean_logs
    data=b'Bearer secret-value\nevi_tg_' + b'A'*43
    frame=b'\x01\x00\x00\x00'+len(data).to_bytes(4,'big')+data
    result=clean_logs(frame)
    assert 'secret-value' not in result
    assert b'A'*43 not in result.encode()


def test_pause_ingest(app):
    from app import db
    import time
    assert app.post('/login',json={'token':'read-'+'Y'*48}).status_code==200
    db.set_setting('ingest_paused','1')
    event={'platform':'telegram','event_id':'pause-event','chat_id':'1',
        'sender_id':'1','ts':time.time()}
    r=app.post('/ingest',json=event,headers={'Authorization':'Bearer master-'+'X'*48})
    assert r.status_code==202 and r.json()['paused'] is True
    assert app.get('/feed').json()['items']==[]
    db.set_setting('ingest_paused','0')
    r=app.post('/ingest',json=event,headers={'Authorization':'Bearer master-'+'X'*48})
    assert r.status_code==202 and r.json()['duplicate'] is False
