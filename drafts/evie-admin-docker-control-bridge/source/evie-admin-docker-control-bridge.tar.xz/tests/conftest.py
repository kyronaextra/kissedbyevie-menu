import os
import sys
import pytest
from fastapi.testclient import TestClient
@pytest.fixture
def app(tmp_path, monkeypatch):
    monkeypatch.setenv('PROFILER_TOKEN', 'master-'+ 'X'*48)
    monkeypatch.setenv('PROFILER_READ_TOKEN', 'read-'+ 'Y'*48)
    monkeypatch.setenv('SESSION_SECRET', 'session-'+ 'Z'*48)
    monkeypatch.setenv('COOKIE_SECURE', 'false')
    monkeypatch.setenv('DB_PATH', str(tmp_path / 'events.sqlite3'))
    # Re-use the already-imported db module held by app.control_worker,
    # but point it at this test's isolated temporary database.
    from app import db
    db.DB_PATH = tmp_path / 'events.sqlite3'
    for module in ('app.auth', 'app.main'):
        sys.modules.pop(module, None)
    from app.main import app
    with TestClient(app) as client:
        yield client

