"""Allowlisted Docker commands; only polls the authenticated Supabase relay.

No listening port and no arbitrary container, shell, compose, image, exec, build,
file-copy or bot-send commands. The Docker socket still has broad host power:
run this trusted image only on the owner's isolated machine.
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
from typing import Any
from urllib.parse import quote

import httpx
from app import db

LOG = logging.getLogger("evie.control")
ALLOWED = frozenset({"api", "listener"})
VERBS = frozenset({"start", "stop", "restart", "logs", "pause", "resume"})
PROJECT = "evie-admin-profiler"
DEFAULT_RELAY = "https://cmjhecwwjoeqpcownkol.supabase.co/functions/v1/evie-control-relay"
RELAY = os.environ.get("EVIE_CONTROL_RELAY_URL", DEFAULT_RELAY)
TOKEN = os.environ.get("EVIE_CONTROL_WORKER_TOKEN", "")
WORKER_ID = os.environ.get("CONTROL_WORKER_ID", "primary-local")
POLL_SECONDS = 5


def validate_configuration():
    if RELAY != DEFAULT_RELAY:
        raise RuntimeError("Relay URL must be the known Supabase project endpoint")
    if len(TOKEN) < 40 or TOKEN.startswith("REPLACE_"):
        raise RuntimeError("EVIE_CONTROL_WORKER_TOKEN must be a strong random secret")
    if not re.fullmatch(r"[a-zA-Z0-9_-]{3,40}", WORKER_ID):
        raise RuntimeError("Invalid worker ID")


async def docker_containers(docker: httpx.AsyncClient) -> dict[str, dict[str, Any]]:
    response = await docker.get("/containers/json", params={"all": "true"})
    response.raise_for_status()
    out: dict[str, dict[str, Any]] = {}
    for item in response.json():
        labels = item.get("Labels", {})
        if labels.get("com.docker.compose.project") != PROJECT:
            continue
        service = labels.get("com.docker.compose.service")
        if service not in ALLOWED:
            continue
        out[service] = {
            "id": item["Id"], "service": service,
            "state": item.get("State", "unknown"),
            "status": str(item.get("Status", ""))[:120],
        }
    return out


def clean_logs(raw: bytes) -> str:
    # Docker non-TTY multiplexed stream: 8-byte frame header + data.
    # A TTY may send plain text instead; fall back gracefully.
    chunks = []
    i = 0
    while i + 8 <= len(raw) and raw[i] in (0, 1, 2, 3) and raw[i + 1:i + 4] == b"\0\0\0":
        size = int.from_bytes(raw[i + 4:i + 8], "big")
        if size > 65536 or i + 8 + size > len(raw):
            break
        chunks.append(raw[i + 8:i + 8 + size])
        i += 8 + size
    output = b"".join(chunks) if chunks and i == len(raw) else raw
    result = output.decode("utf-8", errors="replace")[-6000:]
    # Best-effort log redaction. Never log any bearer token or known token prefix.
    result = re.sub(r"(?i)Bearer\s+\S+", "Bearer [REDACTED]", result)
    result = re.sub(r"evi_tg_[A-Za-z0-9_-]{15,}", "[REDACTED]", result)
    return result


async def perform(command: dict[str, Any], docker: httpx.AsyncClient) -> dict[str, Any]:
    service = command.get("service")
    verb = command.get("verb")
    if service not in ALLOWED or verb not in VERBS:
        raise ValueError("Service or action is not allowlisted")
    if verb in ("pause", "resume"):
        db.init_db()
        state = verb == "pause"
        db.set_setting("ingest_paused", "1" if state else "0")
        return {"paused": state, "service": service}
    containers = await docker_containers(docker)
    matched = containers.get(service)
    if not matched:
        raise ValueError("Service container not found. Launch it with Docker Compose first.")
    # ID always came from a strictly label-filtered Docker response, never from user input.
    ident = quote(matched["id"], safe="")
    if verb == "logs":
        result = await docker.get(f"/containers/{ident}/logs", params={
            "stdout": "true", "stderr": "true", "tail": "80", "timestamps": "false",
        })
        result.raise_for_status()
        return {"service": service, "logs": clean_logs(result.content)}
    response = await docker.post(f"/containers/{ident}/{verb}", params={"t": "10"})
    if response.status_code not in (204, 304):
        response.raise_for_status()
    return {"service": service, "action": verb, "already_in_state": response.status_code == 304}


async def run():
    validate_configuration()
    db.init_db()
    headers = {"Authorization": "Bearer " + TOKEN}
    async with httpx.AsyncClient(
        transport=httpx.AsyncHTTPTransport(uds="/var/run/docker.sock"),
        base_url="http://docker", timeout=22,
    ) as docker, httpx.AsyncClient(timeout=15, follow_redirects=False) as relay:
        next_heartbeat = 0.0
        while True:
            try:
                clock = asyncio.get_running_loop().time()
                if clock >= next_heartbeat:
                    containers = await docker_containers(docker)
                    state = {
                        service: {"state": container["state"], "status": container["status"]}
                        for service, container in containers.items()
                    }
                    reply = await relay.post(RELAY, headers=headers, json={
                        "action": "heartbeat", "worker_id": WORKER_ID,
                        "services": state, "paused": db.get_setting("ingest_paused", "0") == "1",
                    })
                    reply.raise_for_status()
                    next_heartbeat = clock + 20
                response = await relay.post(RELAY, headers=headers, json={
                    "action": "poll", "worker_id": WORKER_ID,
                })
                response.raise_for_status()
                command = response.json().get("command")
                if command:
                    try:
                        result = await perform(command, docker)
                        status = "succeeded"
                    except (httpx.HTTPError, ValueError, OSError) as exc:
                        result = {"error": type(exc).__name__, "message": str(exc)[:180]}
                        status = "failed"
                    response = await relay.post(RELAY, headers=headers, json={
                        "action": "complete", "worker_id": WORKER_ID,
                        "id": command["id"], "status": status, "result": result,
                    })
                    response.raise_for_status()
            except (httpx.HTTPError, OSError, ValueError) as exc:
                # Never print tokens, message bodies, or full response URLs.
                LOG.warning("Control relay unavailable: %s", type(exc).__name__)
            await asyncio.sleep(POLL_SECONDS)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(run())
