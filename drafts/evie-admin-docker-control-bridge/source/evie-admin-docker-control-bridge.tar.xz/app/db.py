"""SQLite is mounted at /app/data; one connection per operation for thread safety."""
from __future__ import annotations
import json
import os
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path

DB_PATH = Path(os.getenv("DB_PATH", "/app/data/profiler.sqlite3"))
RETENTION_DAYS = int(os.getenv("RETENTION_DAYS", "30"))


@contextmanager
def connection():
    db = sqlite3.connect(DB_PATH, timeout=10)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA busy_timeout=5000")
    try:
        yield db
        db.commit()
    finally:
        db.close()


def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with connection() as db:
        db.execute("PRAGMA journal_mode=WAL")
        db.executescript("""
            CREATE TABLE IF NOT EXISTS events (
                pk INTEGER PRIMARY KEY AUTOINCREMENT,
                platform TEXT NOT NULL,
                event_id TEXT NOT NULL,
                chat_id TEXT NOT NULL,
                sender_id TEXT NOT NULL,
                username TEXT NOT NULL DEFAULT '',
                name TEXT NOT NULL DEFAULT '',
                text TEXT NOT NULL DEFAULT '',
                direction TEXT NOT NULL DEFAULT 'inbound',
                ts REAL NOT NULL,
                UNIQUE(platform, event_id)
            );
            CREATE INDEX IF NOT EXISTS idx_events_user ON events(sender_id, pk DESC);
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS profiles (
                sender_id TEXT PRIMARY KEY,
                telegram_id TEXT NOT NULL DEFAULT '',
                tier TEXT NOT NULL DEFAULT 'unclassified',
                ltv_usd REAL,
                spend_30d REAL,
                order_count INTEGER,
                churn_risk TEXT,
                sentiment REAL,
                updated_at REAL NOT NULL
            );
        """)


def insert_event(row: dict) -> tuple[int, bool]:
    with connection() as db:
        before = db.total_changes
        db.execute("""INSERT OR IGNORE INTO events
            (platform,event_id,chat_id,sender_id,username,name,text,direction,ts)
            VALUES (:platform,:event_id,:chat_id,:sender_id,:username,:name,:text,:direction,:ts)""", row)
        created = db.total_changes > before
        result = db.execute("SELECT pk FROM events WHERE platform=? AND event_id=?",
                            (row["platform"], row["event_id"])).fetchone()
        if RETENTION_DAYS > 0:
            db.execute("DELETE FROM events WHERE ts < ?", (time.time() - RETENTION_DAYS * 86400,))
        return result["pk"], created


def from_row(row: sqlite3.Row) -> dict:
    return dict(row)


def events_since(cursor: int, limit: int = 100) -> list[dict]:
    with connection() as db:
        if cursor:
            data = db.execute("SELECT * FROM events WHERE pk > ? ORDER BY pk ASC LIMIT ?", (cursor, limit)).fetchall()
        else:
            data = db.execute("SELECT * FROM (SELECT * FROM events ORDER BY pk DESC LIMIT ?) ORDER BY pk ASC", (limit,)).fetchall()
        return [from_row(r) for r in data]


def upsert_profile(data: dict):
    with connection() as db:
        db.execute("""INSERT INTO profiles
        (sender_id,telegram_id,tier,ltv_usd,spend_30d,order_count,churn_risk,sentiment,updated_at)
        VALUES (:sender_id,:telegram_id,:tier,:ltv_usd,:spend_30d,:order_count,:churn_risk,:sentiment,:updated_at)
        ON CONFLICT(sender_id) DO UPDATE SET
        telegram_id=excluded.telegram_id,tier=excluded.tier,
        ltv_usd=excluded.ltv_usd,spend_30d=excluded.spend_30d,
        order_count=excluded.order_count,churn_risk=excluded.churn_risk,
        sentiment=excluded.sentiment,updated_at=excluded.updated_at""", data)


def profile(sender_id: str) -> dict | None:
    with connection() as db:
        row = db.execute("SELECT * FROM profiles WHERE sender_id=?", (sender_id,)).fetchone()
        return from_row(row) if row else None


def context(sender_id: str, max_chars: int = 2000) -> str:
    with connection() as db:
        rows = db.execute("SELECT platform,username,name,direction,text FROM events WHERE sender_id=? ORDER BY pk DESC LIMIT 40", (sender_id,)).fetchall()
    text = "\n".join(f"{r['platform']} {r['direction']} @{r['username'] or r['name']}: {r['text']}" for r in reversed(rows))
    return text[-max_chars:]


def get_setting(key: str, default: str = "") -> str:
    with connection() as db:
        row = db.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default


def set_setting(key: str, value: str) -> None:
    with connection() as db:
        db.execute("""INSERT INTO settings(key,value) VALUES (?,?)
           ON CONFLICT(key) DO UPDATE SET value=excluded.value""", (key, value))
