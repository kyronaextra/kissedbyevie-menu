"""Read-only Evie profiler dashboard + authenticated ingest/profile endpoints."""
from __future__ import annotations
import asyncio
import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Literal

from fastapi import Depends, FastAPI, HTTPException, Request, Response
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel, Field, field_validator
import json

from app import db
from app.auth import (
    COOKIE_NAME, COOKIE_SECURE, READ, SESSION_SECONDS, auth_master,
    auth_read, constant_match, new_session, require_same_origin,
)

INDEX = Path(__file__).resolve().parent.parent / "web" / "index.html"


@asynccontextmanager
async def lifespan(_: FastAPI):
    db.init_db()
    yield

app = FastAPI(title="Evie Admin Listener API", docs_url=None, redoc_url=None, lifespan=lifespan)


class Login(BaseModel):
    token: str = Field(min_length=1, max_length=300)


class Event(BaseModel):
    platform: Literal["telegram", "x", "snapchat", "other"] = "telegram"
    event_id: str = Field(min_length=1, max_length=180)
    chat_id: str = Field(min_length=1, max_length=180)
    sender_id: str = Field(min_length=1, max_length=180)
    username: str = Field(default="", max_length=80)
    name: str = Field(default="", max_length=120)
    text: str = Field(default="", max_length=1000)
    direction: Literal["inbound", "outbound"] = "inbound"
    ts: float = Field(default_factory=time.time)

    @field_validator("ts")
    @classmethod
    def sensible_timestamp(cls, value: float):
        if not 946684800 <= value <= time.time() + 300:
            raise ValueError("Timestamp outside supported range")
        return value


class Profile(BaseModel):
    sender_id: str = Field(min_length=1, max_length=180)
    telegram_id: str = Field(default="", max_length=180)
    tier: str = Field(default="unclassified", max_length=60)
    ltv_usd: float | None = Field(default=None, ge=0, le=1_000_000_000)
    spend_30d: float | None = Field(default=None, ge=0, le=1_000_000_000)
    order_count: int | None = Field(default=None, ge=0)
    churn_risk: Literal["LOW", "MEDIUM", "HIGH"] | None = None
    sentiment: float | None = Field(default=None, ge=-1.0, le=1.0)


@app.get("/", include_in_schema=False)
def home():
    return FileResponse(INDEX, headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"})


@app.get("/healthz")
def healthz():
    return {"ok": True, "service": "evie-profiler"}


@app.get("/health", dependencies=[Depends(auth_read)])
def health():
    return {"ok": True, "authenticated": True}


@app.post("/login")
def login(credentials: Login, request: Request, response: Response):
    require_same_origin(request)
    if not constant_match(credentials.token, READ):
        raise HTTPException(status_code=401, detail="Incorrect read token")
    response.set_cookie(
        COOKIE_NAME, new_session(), secure=COOKIE_SECURE, httponly=True,
        samesite="strict", max_age=SESSION_SECONDS, path="/",
    )
    response.headers["Cache-Control"] = "no-store"
    return {"ok": True}


@app.post("/logout", dependencies=[Depends(auth_read)])
def logout(request: Request, response: Response):
    require_same_origin(request)
    response.delete_cookie(COOKIE_NAME, path="/", secure=COOKIE_SECURE, httponly=True, samesite="strict")
    return {"ok": True}


@app.get("/feed", dependencies=[Depends(auth_read)])
def feed(since: int = 0, limit: int = 100):
    since = max(0, since)
    limit = max(1, min(limit, 200))
    items = db.events_since(since, limit)
    return {"cursor": items[-1]["pk"] if items else since, "items": items}


@app.get("/profile/{sender_id}", dependencies=[Depends(auth_read)])
def profile(sender_id: str):
    value = db.profile(sender_id)
    if value is None:
        raise HTTPException(status_code=404, detail="No verified profile snapshot")
    return value


@app.get("/context/{sender_id}", dependencies=[Depends(auth_read)])
def context(sender_id: str, max_chars: int = 2000):
    return {"context": db.context(sender_id, max(1, min(max_chars, 4000)))}


@app.get("/live", dependencies=[Depends(auth_read)])
async def live(request: Request):
    async def stream():
        cursor = 0
        last_ping = 0.0
        while not await request.is_disconnected():
            batch = await asyncio.to_thread(db.events_since, cursor, 100)
            if batch:
                for item in batch:
                    cursor = item["pk"]
                    yield f"data: {json.dumps(item, ensure_ascii=False)}\n\n"
            elif time.monotonic() - last_ping > 15:
                yield ": heartbeat\n\n"
                last_ping = time.monotonic()
            await asyncio.sleep(1)
    return StreamingResponse(stream(), media_type="text/event-stream", headers={
        "Cache-Control": "no-cache, no-transform", "X-Accel-Buffering": "no",
    })


@app.post("/ingest", status_code=202, dependencies=[Depends(auth_master)])
def ingest(event: Event, request: Request):
    if request.headers.get("origin"):
        raise HTTPException(status_code=403, detail="Browser ingestion denied")
    if db.get_setting("ingest_paused", "0") == "1":
        return {"ok": True, "paused": True, "accepted": False}
    pk, created = db.insert_event(event.model_dump())
    return {"ok": True, "pk": pk, "duplicate": not created}


@app.post("/profile", status_code=202, dependencies=[Depends(auth_master)])
def update_profile(profile: Profile, request: Request):
    if request.headers.get("origin"):
        raise HTTPException(status_code=403, detail="Browser updates denied")
    db.upsert_profile({**profile.model_dump(), "updated_at": time.time()})
    return {"ok": True}
